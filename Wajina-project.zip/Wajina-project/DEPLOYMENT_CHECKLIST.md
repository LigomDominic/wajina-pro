# Deployment Checklist

Use this checklist to ensure your Wajina Suite is ready for production deployment.

## Pre-Deployment

### Code Quality
- [ ] All features tested locally
- [ ] No debug print statements in production code
- [ ] Error handling implemented throughout
- [ ] Security vulnerabilities addressed
- [ ] Code follows best practices

### Configuration Files
- [ ] `requirements.txt` is up to date with all dependencies
- [ ] `Procfile` exists and is correct
- [ ] `runtime.txt` specifies Python version
- [ ] `gunicorn_config.py` is configured
- [ ] `.gitignore` excludes sensitive files
- [ ] `render.yaml` is configured (if using Render)

### Security
- [ ] `SECRET_KEY` is strong and unique (not default)
- [ ] `FLASK_ENV=production` will be set
- [ ] No hardcoded credentials in code
- [ ] All sensitive data uses environment variables
- [ ] Database uses PostgreSQL in production (not SQLite)
- [ ] File upload limits are configured
- [ ] SQL injection protection verified (SQLAlchemy handles this)

### Database
- [ ] Production database (PostgreSQL) is set up
- [ ] `DATABASE_URL` environment variable will be configured
- [ ] Database migration plan is ready
- [ ] Backup strategy is in place

### Files and Assets
- [ ] All necessary static files are included
- [ ] Upload directories structure is correct
- [ ] No large files committed to git
- [ ] All templates are present

## Deployment Platform Setup

### GitHub Repository
- [ ] Repository created on GitHub
- [ ] All code committed and pushed
- [ ] `requirements.txt` is in repository root
- [ ] Repository is accessible to deployment platform
- [ ] Branch name is correct (usually `main` or `master`)

### Render.com Setup
- [ ] Render account created
- [ ] GitHub connected to Render
- [ ] PostgreSQL database created
- [ ] Web service created
- [ ] Environment variables configured:
  - [ ] `SECRET_KEY`
  - [ ] `FLASK_ENV=production`
  - [ ] `DATABASE_URL`
  - [ ] Email settings (if using)
  - [ ] Flutterwave keys (if using)
- [ ] Database linked to web service

### Other Platforms
- [ ] Platform account created
- [ ] Repository connected
- [ ] Database provisioned
- [ ] Environment variables set
- [ ] Build and start commands configured

## Post-Deployment

### Initial Setup
- [ ] Application deployed successfully
- [ ] Application is accessible via URL
- [ ] Database tables created (run `db.create_all()`)
- [ ] Default admin user created
- [ ] Can access login page

### Configuration
- [ ] Admin password changed from default
- [ ] School information configured
- [ ] Email settings tested (if using)
- [ ] Payment gateway tested (if using)
- [ ] Custom domain configured (optional)
- [ ] SSL certificate active (usually automatic)

### Testing
- [ ] Login/Logout works
- [ ] User creation works
- [ ] File uploads work
- [ ] Database operations work
- [ ] Email sending works (if configured)
- [ ] Payment processing works (if configured)
- [ ] Reports generate correctly
- [ ] All major features tested

### Monitoring
- [ ] Error logging is working
- [ ] Application logs are accessible
- [ ] Monitoring/alerting set up (optional)
- [ ] Backup schedule configured

## Security Hardening

- [ ] Default admin password changed
- [ ] Strong SECRET_KEY in use
- [ ] HTTPS enabled (usually automatic)
- [ ] CORS configured if needed
- [ ] Rate limiting considered
- [ ] Input validation verified
- [ ] File upload security verified

## Performance

- [ ] Database queries optimized
- [ ] Static files served efficiently
- [ ] Caching configured (if needed)
- [ ] CDN configured (optional)
- [ ] Image optimization done

## Documentation

- [ ] Deployment documentation updated
- [ ] Environment variables documented
- [ ] Troubleshooting guide available
- [ ] Contact information for support

## Rollback Plan

- [ ] Know how to rollback if needed
- [ ] Database backup before major changes
- [ ] Previous version accessible

---

## Quick Deployment Commands

### Initialize Database (on deployment platform)
```bash
python -c "from app import app, db; app.app_context().push(); db.create_all()"
```

### Verify Deployment
```bash
python verify_deployment.py
```

### Check Logs
- Render: Dashboard → Logs tab
- Other platforms: Check platform-specific log location

---

**Last Updated**: 2024
**Version**: 1.0

