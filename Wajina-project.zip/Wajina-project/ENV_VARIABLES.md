# Environment Variables Reference

This document lists all environment variables used by Wajina Suite.

## Required Variables

### SECRET_KEY
- **Description**: Flask secret key for session management and CSRF protection
- **Example**: `SECRET_KEY=your-strong-secret-key-here`
- **How to generate**: 
  ```python
  import secrets
  print(secrets.token_hex(32))
  ```
- **Production**: MUST be set to a strong random value

### FLASK_ENV
- **Description**: Flask environment mode
- **Values**: `development` or `production`
- **Default**: `development` (if not set)
- **Production**: MUST be set to `production`

### DATABASE_URL
- **Description**: Database connection string
- **Local (SQLite)**: `sqlite:///wajina_suite.db`
- **Production (PostgreSQL)**: `postgresql://username:password@host:port/database_name`
- **Production**: MUST use PostgreSQL

## Optional Variables

### PORT
- **Description**: Port number for the server
- **Default**: `5000`
- **Production**: Usually set automatically by hosting platform

### Email Configuration

#### MAIL_SERVER
- **Description**: SMTP server address
- **Example**: `smtp.gmail.com`
- **Default**: `smtp.gmail.com`

#### MAIL_PORT
- **Description**: SMTP server port
- **Example**: `587` (TLS) or `465` (SSL)
- **Default**: `587`

#### MAIL_USE_TLS
- **Description**: Enable TLS encryption
- **Values**: `True` or `False`
- **Default**: `True`

#### MAIL_USERNAME
- **Description**: Email address for sending emails
- **Example**: `your-email@gmail.com`

#### MAIL_PASSWORD
- **Description**: Email password or app-specific password
- **Note**: For Gmail, use an App Password, not your regular password

#### MAIL_DEFAULT_SENDER
- **Description**: Default sender email address
- **Example**: `your-email@gmail.com`

### Flutterwave Payment Gateway

#### FLUTTERWAVE_PUBLIC_KEY
- **Description**: Flutterwave public API key
- **Get from**: Flutterwave Dashboard

#### FLUTTERWAVE_SECRET_KEY
- **Description**: Flutterwave secret API key
- **Get from**: Flutterwave Dashboard
- **Security**: Keep this secret!

#### FLUTTERWAVE_ENCRYPTION_KEY
- **Description**: Flutterwave encryption key
- **Get from**: Flutterwave Dashboard

#### FLUTTERWAVE_ENVIRONMENT
- **Description**: Flutterwave environment
- **Values**: `sandbox` (testing) or `live` (production)
- **Default**: `sandbox`

## Setting Environment Variables

### Local Development
Create a `.env` file in the project root:
```bash
SECRET_KEY=your-secret-key
FLASK_ENV=development
DATABASE_URL=sqlite:///wajina_suite.db
```

### Production (Render.com)
Set in Render Dashboard → Environment tab

### Production (Other Platforms)
Set according to your platform's documentation

## Security Notes

1. **Never commit `.env` files** to version control
2. **Use strong SECRET_KEY** in production
3. **Keep API keys secret** - never expose in code or logs
4. **Use environment variables** for all sensitive data
5. **Rotate keys regularly** in production

