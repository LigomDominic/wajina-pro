"""
Helper script to set up PostgreSQL database for Wajina Suite
Run this script to create database, user, and initialize tables
"""

import os
import sys
import psycopg2
from psycopg2 import sql
from getpass import getpass

def create_database_and_user():
    """Create PostgreSQL database and user"""
    
    print("=" * 60)
    print("PostgreSQL Setup for Wajina Suite")
    print("=" * 60)
    
    # Get PostgreSQL admin credentials
    print("\nEnter PostgreSQL admin credentials:")
    admin_user = input("Admin username [postgres]: ").strip() or "postgres"
    admin_password = getpass("Admin password: ")
    
    # Get database details
    print("\nEnter database details:")
    db_name = input("Database name [wajina_suite]: ").strip() or "wajina_suite"
    db_user = input("Database user [wajina_user]: ").strip() or "wajina_user"
    db_password = getpass("Database user password: ")
    
    if not db_password:
        print("Error: Database user password cannot be empty!")
        return False
    
    # Get host and port
    host = input("Host [localhost]: ").strip() or "localhost"
    port = input("Port [5432]: ").strip() or "5432"
    
    try:
        # Connect as admin
        print(f"\nConnecting to PostgreSQL as {admin_user}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=admin_user,
            password=admin_password,
            database='postgres'  # Connect to default database
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s",
            (db_name,)
        )
        db_exists = cursor.fetchone()
        
        if db_exists:
            print(f"Database '{db_name}' already exists.")
            response = input("Do you want to drop and recreate it? (yes/no): ").strip().lower()
            if response == 'yes':
                # Terminate existing connections
                cursor.execute(
                    sql.SQL("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = %s AND pid <> pg_backend_pid()"),
                    (db_name,)
                )
                cursor.execute(sql.SQL("DROP DATABASE {}").format(sql.Identifier(db_name)))
                print(f"Database '{db_name}' dropped.")
            else:
                print("Using existing database.")
        else:
            # Create database
            print(f"Creating database '{db_name}'...")
            cursor.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db_name)))
            print(f"Database '{db_name}' created successfully!")
        
        # Check if user exists
        cursor.execute(
            "SELECT 1 FROM pg_roles WHERE rolname = %s",
            (db_user,)
        )
        user_exists = cursor.fetchone()
        
        if user_exists:
            print(f"User '{db_user}' already exists.")
            response = input("Do you want to update the password? (yes/no): ").strip().lower()
            if response == 'yes':
                cursor.execute(
                    sql.SQL("ALTER USER {} WITH PASSWORD %s").format(sql.Identifier(db_user)),
                    (db_password,)
                )
                print(f"Password updated for user '{db_user}'.")
        else:
            # Create user
            print(f"Creating user '{db_user}'...")
            cursor.execute(
                sql.SQL("CREATE USER {} WITH PASSWORD %s").format(sql.Identifier(db_user)),
                (db_password,)
            )
            print(f"User '{db_user}' created successfully!")
        
        # Grant privileges
        print(f"Granting privileges to '{db_user}'...")
        cursor.execute(
            sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}").format(
                sql.Identifier(db_name),
                sql.Identifier(db_user)
            )
        )
        
        # Connect to the new database to grant schema privileges
        conn.close()
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=admin_user,
            password=admin_password,
            database=db_name
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Grant schema privileges (for PostgreSQL 15+)
        cursor.execute(
            sql.SQL("GRANT ALL ON SCHEMA public TO {}").format(sql.Identifier(db_user))
        )
        cursor.execute(
            sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO {}").format(
                sql.Identifier(db_user)
            )
        )
        
        cursor.close()
        conn.close()
        
        # Generate connection string
        database_url = f"postgresql://{db_user}:{db_password}@{host}:{port}/{db_name}"
        
        print("\n" + "=" * 60)
        print("Setup completed successfully!")
        print("=" * 60)
        print(f"\nDatabase: {db_name}")
        print(f"User: {db_user}")
        print(f"Host: {host}:{port}")
        print(f"\nConnection String:")
        print(f"DATABASE_URL={database_url}")
        print("\nAdd this to your .env file:")
        print(f"DATABASE_URL={database_url}")
        print("\nOr set as environment variable:")
        if sys.platform == 'win32':
            print(f'set DATABASE_URL={database_url}')
        else:
            print(f'export DATABASE_URL={database_url}')
        
        return True
        
    except psycopg2.Error as e:
        print(f"\nError: {e}")
        return False
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        return False

def initialize_tables():
    """Initialize database tables using Flask app"""
    print("\n" + "=" * 60)
    print("Initializing Database Tables")
    print("=" * 60)
    
    try:
        from app import app, db
        
        with app.app_context():
            print("Creating tables...")
            db.create_all()
            print("Tables created successfully!")
            
            # Check if admin user exists
            from models import User
            admin = User.query.filter_by(username='admin').first()
            if not admin:
                print("\nCreating default admin user...")
                from werkzeug.security import generate_password_hash
                admin = User(
                    username='admin',
                    email='admin@wajina.com',
                    password_hash=generate_password_hash('admin123'),
                    role='admin',
                    first_name='Admin',
                    last_name='User',
                    is_active=True
                )
                db.session.add(admin)
                db.session.commit()
                print("Admin user created!")
                print("Username: admin")
                print("Password: admin123")
                print("⚠️  IMPORTANT: Change this password after first login!")
            else:
                print("\nAdmin user already exists.")
        
        return True
        
    except Exception as e:
        print(f"\nError initializing tables: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    print("\nThis script will help you set up PostgreSQL for Wajina Suite.")
    print("You need PostgreSQL installed and running.")
    print("\nOptions:")
    print("1. Create database and user only")
    print("2. Create database, user, and initialize tables")
    print("3. Initialize tables only (database already exists)")
    
    choice = input("\nEnter your choice (1/2/3): ").strip()
    
    if choice == '1':
        create_database_and_user()
    elif choice == '2':
        if create_database_and_user():
            print("\nProceeding to initialize tables...")
            initialize_tables()
    elif choice == '3':
        initialize_tables()
    else:
        print("Invalid choice!")

