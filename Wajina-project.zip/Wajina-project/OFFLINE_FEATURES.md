# Offline Functionality Documentation

## Overview
Wajina Suite now supports offline functionality, allowing users to access the application even when internet connectivity is low or unavailable.

## Features Implemented

### 1. Service Worker
- **Location**: `static/js/service-worker.js`
- **Functionality**:
  - Caches static assets (CSS, JS, images)
  - Caches HTML pages for offline access
  - Handles API requests with offline fallback
  - Automatically updates cache when new version is available

### 2. Offline Handler
- **Location**: `static/js/offline-handler.js`
- **Functionality**:
  - Registers service worker
  - Monitors online/offline status
  - Shows offline indicator
  - Queues form submissions when offline
  - Syncs pending data when connection is restored

### 3. Web App Manifest
- **Location**: `static/manifest.json`
- **Functionality**:
  - Makes the app installable on mobile devices
  - Defines app icons and theme colors
  - Enables PWA (Progressive Web App) features

### 4. Offline Page
- **Location**: `templates/offline.html`
- **Functionality**:
  - Displays when user is offline and page not cached
  - Provides navigation options
  - Explains offline capabilities

## How It Works

### Caching Strategy
1. **Static Assets**: Cached immediately on first visit
2. **HTML Pages**: Cached as user visits them
3. **API Responses**: Cached for offline access
4. **Images**: Cached with placeholder fallback

### Offline Access
- Users can view previously visited pages
- Forms can be filled offline (queued for submission)
- Cached data is available instantly
- Offline indicator shows connection status

## User Experience

### Online Mode
- Normal functionality
- Real-time data updates
- Full feature access

### Offline Mode
- Offline indicator appears at top of page
- Cached pages load instantly
- Forms can be filled (will sync when online)
- Limited to previously visited content

## Browser Support
- Chrome/Edge: Full support
- Firefox: Full support
- Safari: Full support (iOS 11.3+)
- Opera: Full support

## Testing Offline Mode

### Chrome DevTools
1. Open DevTools (F12)
2. Go to "Application" tab
3. Click "Service Workers"
4. Check "Offline" checkbox
5. Refresh page to test offline functionality

### Network Throttling
1. Open DevTools (F12)
2. Go to "Network" tab
3. Set throttling to "Offline"
4. Test application behavior

## Configuration

### Cache Version
Update `CACHE_NAME` in `static/js/service-worker.js` to force cache refresh:
```javascript
const CACHE_NAME = 'wajina-suite-v2'; // Increment version
```

### Manifest Settings
Edit `static/manifest.json` to customize:
- App name and description
- Theme colors
- Icons
- Display mode

## Troubleshooting

### Service Worker Not Registering
- Check browser console for errors
- Ensure HTTPS (or localhost for development)
- Clear browser cache and try again

### Cache Not Updating
- Increment cache version in service worker
- Clear browser cache
- Unregister old service worker

### Offline Page Not Showing
- Ensure `/offline` route is accessible
- Check service worker is active
- Verify offline handler script is loaded

## Future Enhancements
- IndexedDB for larger data storage
- Background sync for form submissions
- Push notifications
- Offline-first data strategy

