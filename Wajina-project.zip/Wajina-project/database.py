"""
Database initialization for Wajina Suite
"""

from flask_sqlalchemy import SQLAlchemy

# Create db instance that will be shared across modules
db = SQLAlchemy()

